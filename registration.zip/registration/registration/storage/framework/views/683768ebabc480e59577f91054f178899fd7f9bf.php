<h1>login</h1>
<?php /**PATH C:\xampp\htdocs\demo1\resources\views/login/login.blade.php ENDPATH**/ ?>